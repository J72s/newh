const { Client } = require('discord.js-selfbot-v13');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, VoiceConnectionStatus, AudioPlayerStatus } = require('@discordjs/voice');
const ytdl = require('ytdl-core');
const fetch = require('node-fetch');
const fs = require('fs');
const config = require('./config'); // Import the configuration
const ffmpegPath = require('ffmpeg-static'); // Path to ffmpeg

const client = new Client();
const messages = JSON.parse(fs.readFileSync('messages.json', 'utf8')).messages;
let intervalId = null;
let adminUserIds = config.adminUserIds;

client.on('ready', async () => {
  console.log(`${client.user.username} is ready!`);
});

client.on('message', async (message) => {
  // Check if adminUserIds and specificChannelId are correctly loaded
  if (!Array.isArray(adminUserIds) || typeof config.specificChannelId !== 'string') {
    console.error('Configuration is invalid. Please check your config.js file.');
    return;
  }

  // Restrict the bot to respond only to admins in the specific channel
  if (!adminUserIds.includes(message.author.id) || message.channel.id !== config.specificChannelId) return;

  // Check if the bot is mentioned in the message
  if (!message.mentions.has(client.user)) return;

  // Remove the bot mention from the message content
  const args = message.content.replace(`<@${client.user.id}>`, '').trim().split(' ');
  const command = args[0];

  if (command === 'vc') {
    const channelId = args[1];

    if (!channelId) {
      message.reply('Please provide a valid channel ID.');
      return;
    }

    const channel = await client.channels.fetch(channelId);

    if (channel && channel.isVoice()) {
      joinVoiceChannel({
        channelId: channel.id,
        guildId: channel.guild.id,
        adapterCreator: channel.guild.voiceAdapterCreator,
        selfDeaf: false,
        selfMute: false,
      });

      message.reply(`Joined voice channel: ${channel.name}`);
    } else {
      message.reply('Invalid voice channel ID.');
    }
  } else if (command === 'def') {
    const channelId = args[1];

    if (!channelId) {
      message.reply('Please provide a valid channel ID.');
      return;
    }

    const channel = await client.channels.fetch(channelId);

    if (channel && channel.isVoice()) {
      joinVoiceChannel({
        channelId: channel.id,
        guildId: channel.guild.id,
        adapterCreator: channel.guild.voiceAdapterCreator,
        selfDeaf: true,
        selfMute: true,
      });

      message.reply(`Joined voice channel: ${channel.name}`);
    } else {
      message.reply('Invalid voice channel ID.');
    }
  } else if (command === 'mu') {
    const channelId = args[1];

    if (!channelId) {
      message.reply('Please provide a valid channel ID.');
      return;
    }

    const channel = await client.channels.fetch(channelId);

    if (channel && channel.isVoice()) {
      joinVoiceChannel({
        channelId: channel.id,
        guildId: channel.guild.id,
        adapterCreator: channel.guild.voiceAdapterCreator,
        selfDeaf: false,
        selfMute: true,
      });

      message.reply(`Joined voice channel: ${channel.name}`);
    } else {
      message.reply('Invalid voice channel ID.');
    }
  } else if (command === 'ava') {
    const imageUrl = args[1];

    if (!imageUrl) {
      message.reply('Please provide a valid image URL.');
      return;
    }

    try {
      const response = await fetch(imageUrl);
      const buffer = await response.buffer();

      await client.user.setAvatar(buffer);
      message.reply('Avatar changed successfully!');
    } catch (error) {
      console.error(error);
      message.reply('Failed to change avatar. Make sure the URL is correct and points to a valid image.');
    }
  } else if (command === 'bankon') {
    const channelId = args[1];

    if (!channelId) {
      message.reply('Please provide a valid channel ID.');
      return;
    }

    const channel = await client.channels.fetch(channelId);

    if (channel && channel.isText()) {
      if (intervalId) {
        clearInterval(intervalId); // Clear any existing interval
      }

      intervalId = setInterval(() => {
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        channel.send(randomMessage);
      }, 5 * 60 * 1000); // 5 minutes

      message.reply(`Started sending random messages to channel: ${channel.name}`);
    } else {
      message.reply('Invalid text channel ID.');
    }
  } else if (command === 'bankoff') {
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
      message.reply('Stopped sending random messages.');
    } else {
      message.reply('No active message interval to stop.');
    }
  } else if (command === 'setadmin') {
    const newAdminId = args[1];

    if (!newAdminId) {
      message.reply('Please provide a valid user ID.');
      return;
    }

    adminUserIds.push(newAdminId);
    message.reply(`New admin set: <@${newAdminId}>`);
  } else if (command === 'stream') {
    const channelId = args[1];
    const youtubeUrl = args[2];

    if (!channelId || !youtubeUrl) {
      message.reply('Please provide a valid channel ID and YouTube URL.');
      return;
    }

    const channel = await client.channels.fetch(channelId);

    if (channel && channel.isVoice()) {
      const connection = joinVoiceChannel({
        channelId: channel.id,
        guildId: channel.guild.id,
        adapterCreator: channel.guild.voiceAdapterCreator,
        selfDeaf: false,
        selfMute: false,
      });

      connection.on(VoiceConnectionStatus.Ready, () => {
        console.log('The bot has connected to the channel!');
        
        // Create a stream with ytdl and ffmpeg
        const stream = ytdl(youtubeUrl, { filter: 'audioonly', quality: 'highestaudio' });
        const resource = createAudioResource(stream, { inputType: 'opus', inlineVolume: true });
        const player = createAudioPlayer();

        player.play(resource);
        connection.subscribe(player);

        player.on(AudioPlayerStatus.Playing, () => {
          console.log('The audio is now playing!');
        });

        player.on('error', error => {
          console.error(`Error: ${error.message}`);
        });

        message.reply(`Started streaming: ${youtubeUrl}`);
      });
    } else {
      message.reply('Invalid voice channel ID.');
    }
  }
});

client.login(config.token);
