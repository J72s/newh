module.exports = {
    token: 'MTE4ODk3MTAyODA3Mjg5ODYzNA.GclaBq.6WlcbhuHWSB7H0de3gs2kY2EjrDWJ1NL_l9tl0',
    adminUserIds: ['520774569855025152', '764205712536371232', '414905511113261068'], // List of initial admin user IDs
    specificChannelId: '1243292762456064061' // Channel where the bot will respond
  };
  