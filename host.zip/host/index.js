const { Client, GatewayIntentBits } = require('discord.js');
const { Client: SSHClient } = require('ssh2');
const fs = require('fs');
const readline = require('readline');

const DISCORD_TOKEN = '';
const SSH_CONFIG = {
    host: '165.227.117.206',
    port: 22,
    username: 'master_yuvkugzzak',
    password: 'Ssaa1122'
};
// Create the Discord bot client
const bot = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

bot.once('ready', () => {
    console.log(`Logged in as ${bot.user.tag}`);
});

bot.on('messageCreate', async message => {
    if (message.content.startsWith('!runbot')) {
        const tokens = await readTokensFromFile('tokens.txt');

        tokens.forEach((token, index) => {
            const configFilePath = `//config${index}.js`;
            updateConfigFile(configFilePath, token, (err) => {
                if (err) {
                    message.reply(`Failed to update config file: ${err.message}`);
                    return;
                }

                runBotOnSSH(message, configFilePath, index);
            });
        });
    } else if (message.content === '!tokens') {
        const tokens = await readTokensFromFile('tokens.txt');
        const embed = new EmbedBuilder()
            .setTitle('Token Information')
            .setDescription(`There are ${tokens.length} tokens in tokens.txt.`)
            .setColor(0x00FF00);
        message.reply({ embeds: [embed] });
    } else if (message.content.startsWith('!setname')) {
        const newName = message.content.split(' ').slice(1).join(' ');
        if (!newName) {
            message.reply('Please provide a new name for the bot.');
            return;
        }
        bot.user.setUsername(newName)
            .then(user => message.reply(`Bot name changed to: ${user.username}`))
            .catch(err => message.reply(`Failed to change bot name: ${err.message}`));
    } else if (message.content.startsWith('!setavatar')) {
        const url = message.content.split(' ')[1];
        if (!url) {
            message.reply('Please provide a URL for the new avatar.');
            return;
        }
        try {
            const response = await fetch(url);
            const buffer = await response.buffer();
            bot.user.setAvatar(buffer)
                .then(user => message.reply('Bot avatar changed successfully.'))
                .catch(err => message.reply(`Failed to change bot avatar: ${err.message}`));
        } catch (err) {
            message.reply(`Failed to fetch image from URL: ${err.message}`);
        }
    } else if (message.content === '!screens') {
        listScreensOnSSH(message);
    } else if (message.content.startsWith('!killscreen')) {
        const screenName = message.content.split(' ')[1];
        if (!screenName) {
            message.reply('Please provide the screen name to kill.');
            return;
        }
        killScreenOnSSH(message, screenName);
    }
});

async function readTokensFromFile(filePath) {
    const fileStream = fs.createReadStream(filePath);
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });

    const tokens = [];
    for await (const line of rl) {
        tokens.push(line.trim());
    }

    return tokens;
}

function updateConfigFile(configFilePath, newToken, callback) {
    fs.readFile(configFilePath, 'utf8', (err, data) => {
        if (err) {
            callback(err);
            return;
        }

        const updatedConfig = data.replace(/token:\s*".*"/, `token: "${newToken}"`);

        fs.writeFile(configFilePath, updatedConfig, 'utf8', callback);
    });
}

function runBotOnSSH(message, configFilePath, index) {
    const conn = new SSHClient();
    const screenName = `bot_screen_${index}`;
    conn.on('ready', () => {
        console.log('SSH Client :: ready');
        conn.exec(`screen -dmS ${screenName} node //index.js`, (err, stream) => {
            if (err) {
                message.reply(`Failed to execute command: ${err.message}`);
                return;
            }
            stream.on('close', (code, signal) => {
                conn.end();
                if (code !== 0) {
                    message.reply(`Bot script exited with code: ${code}, signal: ${signal}`);
                } else {
                    message.reply(`Bot started successfully in screen: ${screenName}`);
                }
            }).on('data', data => {
                console.log('STDOUT: ' + data);
            }).stderr.on('data', data => {
                console.error('STDERR: ' + data);
                message.reply(`Error: ${data}`);
            });
        });
    }).connect(SSH_CONFIG);
}

function listScreensOnSSH(message) {
    const conn = new SSHClient();
    conn.on('ready', () => {
        console.log('SSH Client :: ready');
        conn.exec('screen -ls', (err, stream) => {
            if (err) {
                message.reply(`Failed to list screens: ${err.message}`);
                return;
            }
            let output = '';
            stream.on('close', (code, signal) => {
                conn.end();
                message.reply(`Available screens:\n${output}`);
            }).on('data', data => {
                output += data;
            }).stderr.on('data', data => {
                console.error('STDERR: ' + data);
            });
        });
    }).connect(SSH_CONFIG);
}

function killScreenOnSSH(message, screenName) {
    const conn = new SSHClient();
    conn.on('ready', () => {
        console.log('SSH Client :: ready');
        conn.exec(`screen -S ${screenName} -X quit`, (err, stream) => {
            if (err) {
                message.reply(`Failed to kill screen: ${err.message}`);
                return;
            }
            stream.on('close', (code, signal) => {
                conn.end();
                message.reply(`Screen ${screenName} killed successfully.`);
            }).on('data', data => {
                console.log('STDOUT: ' + data);
            }).stderr.on('data', data => {
                console.error('STDERR: ' + data);
            });
        });
    }).connect(SSH_CONFIG);
}

// Log in to Discord
bot.login(DISCORD_TOKEN);
